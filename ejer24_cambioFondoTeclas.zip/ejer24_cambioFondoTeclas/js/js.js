function cambiarColor() {
    
    //Obtiene el color de fondo. Bucle para hacer animación
    for (var i = 0; i < 10; i++) {
        var color = "rgb(" + aleatorio() + "," + aleatorio() + "," + aleatorio() + ")";

        document.querySelector("body").style.backgroundColor = color;
    }
    
    //Incluye en la cabecera un span con estilo y evento JS
    document.querySelector("#cabecera").innerHTML +=
            "<span style=background-color:" + color + "; onclick=\"document.querySelector('body').style.backgroundColor = '" +  color.toString() + "' \"; onmousedown=\"document.querySelector('#nomColor').innerHTML = '<p>" + color + "</p>'\"; >"
            + "  " +
            "</span>";
    
   
    //Obtiene el color de fondo y se introduce en el div para el nombre del color
    document.querySelector("#nomColor").innerHTML = "<p>" + color + "</p>";
}

function aleatorio() {
    var num = Math.floor((Math.random() * 250) * 1);
    console.log(num);
    return num;
}

window.onload = function () {

    document.querySelector("body").onkeypress = function () {
        cambiarColor();
    };

};